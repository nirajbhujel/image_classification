import torch
import torch.nn as nn
import torch.nn.functional as F

import numpy as np

class BCE_Loss:
	def __init__(self, cls_weights=None, reduction='mean'):
		super().__init__()
        
        if cls_weights is None:
            cls_weights = torch.tensor(cls_weights)
            reduction = None
        self.cls_weights = cls_weights
		self.func = nn.BCELoss(reduction=reduction)

	def compute(self, y_true, y_pred):
        B, C = y_true.shape
		assert y_pred.shape==y_true.shape, f"{y_pred.shape=} is not equal to {y_true.shape=}"
		y_pred = F.softmax(y_pred, dim=-1)
        loss = self.func(y_pred, y_true)
            
		return loss